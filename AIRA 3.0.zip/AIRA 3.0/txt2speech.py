import speech_recognition as sr

def listen_and_recognize():
    r = sr.Recognizer()

    with sr.Microphone() as source:
        print("Listening...")
        r.adjust_for_ambient_noise(source)

        while True:
            try:
                audio = r.listen(source, timeout=1)  # Set a timeout of 1 second
                if audio:
                    print("Recognizing...")
                    text = r.recognize_google(audio)
                    print("Recognized Text: " + text)
            except sr.UnknownValueError:
                print("Unable to recognize speech")
            except sr.RequestError as e:
                print("Error: {0}".format(e))
            except sr.WaitTimeoutError:
                pass


listen_and_recognize()
